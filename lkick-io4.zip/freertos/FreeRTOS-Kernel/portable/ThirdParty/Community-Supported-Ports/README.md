## FreeRTOS-Kernel-Community-Supported-Ports

This repository is under construction.

## Security

See [CONTRIBUTING](.github/CONTRIBUTING.md#security-issue-notifications) for more information.

## License

This repository contains multiple directories, each individually licensed. Please see the LICENSE file in each directory.
